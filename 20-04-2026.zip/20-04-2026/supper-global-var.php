<?php

$_COOKIE

$_ENV

$_FILES

$_GET

$_POST

$_REQUEST    

$_SESSION

$_SERVER

$_ENV

$_FILES

$_GLOBAL

$_REQUEST

?>