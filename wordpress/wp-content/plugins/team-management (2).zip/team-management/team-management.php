<?php

/**
 * Plugin Name: Team Management
 * Plugin URI: https://team-management.com/
 * Description: A plugin for managing teams and their activities.
 * Version: 1.0.0
 * Author: Masum
 * Author URI: https://team-management.com
 * Text Domain: team-management
 */

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
if(!session_id()) session_start();


// echo "Hello, World! This is the Team Management plugin.";


function team_management_menu()
{
	add_menu_page(
		'Team Management List', // Page title
		'TeamManagement', // Menu title
		'manage_options',  // Capability
		'team-list', // Menu slug
		'team_members_list', // Callback function
		'dashicons-admin-site-alt3', // Icon URL
		6 // Position
	);

	add_submenu_page(
		'team-list', // Parent slug
		'Add Team', // Page title
		'Add Team', // Menu title
		'manage_options', // Capability
		'add-team', // Menu slug
		'team_members_add' // Callback function
	);
	add_submenu_page(
		'team-edit', // Parent slug
		'Edit Team Member', // Page title
		'Edit Member', // Menu title
		'manage_options', // Capability
		'team-edit', // Menu slug
		'team_member_edit' // Callback function
	);
}

add_action('admin_menu', 'team_management_menu');

function test()
{
	echo "Hello, World! This is the Team Management plugin.";
}


function team_members_list()
{
	global $wpdb;
	$table_name = $wpdb->prefix . 'team_members';

	    
    if(isset($_SESSION['flash_msg'])) {
         echo "<div class='notice notice-success is-dismissible'>
                 <p>{$_SESSION['flash_msg']}</p>
            </div>
            ";
        unset($_SESSION['flash_msg']);    
    }

	if (isset($_POST['delete_id'])){
		// echo $_POST['delete_id'];
		$delete_res = $wpdb->delete(
			$table_name,
			array('id' => $_POST['delete_id'])
		);
		if($delete_res){
			echo "<div class='notice notice-success is-dismissible'>
			<p>Team member deleted successfully!</p></div>";
		}else{
			echo "<div class='notice notice-error is-dismissible'>
			<p>Error deleting team member.</p></div>";
		}
	}


	
	$results = $wpdb->get_results("SELECT * FROM $table_name");

	// echo "<pre>";
	// print_r($results);
	// echo "</pre>";

	$table_body = '';
	foreach ($results as $item) {
		if($item->image != null){
			$img = wp_get_attachment_url($item->image);
		}else{
			$img ="https://placehold.co/60x60.png";
		}
		$table_body .= "
	<tr>
			<td class='column-name'>{$item->name}</td>
            <td class='column-name'>{$item->role}</td>
            <td class='column-name'>{$item->email}</td>
            <td class='column-name'><img src='{$img}' width='60' height='60' alt='Team Member Image'></td>
            <td class='column-name'>
			<a href='admin.php?page=team-edit&id={$item->id}' class='button' style='width: 100px; text-align: center; background-color: #0073aa; color: #fff;'>Edit</a>
				<form action='' method='POST'>
				<input type='hidden' name='delete_id' value= '$item->id'>
				<input type='submit' class='button' style='width: 100px; text-align: center; background-color: #dc3232; color: #fff;' value='Delete'>
				</form>
			</td>
	</tr>
			";
	}


	// Code to display the list of team members
	echo "<h2>Team Members List</h2>
    <table class='wp-list-table widefat fixed striped table-view-list tags'>
	<thead>
		<tr>
			<th scope='col' class='manage-column column-name column-primary sorted asc'>
				<a>Name</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Designation</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Email</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Image</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Action</a>
			</th>
		</tr>
	</thead>
	<tbody data-wp-lists='list:tag'>
		$table_body
	</tbody>	
</table>";
}

function team_members_add()
{
	if (isset($_POST['submit'])) {
	// 	echo $_POST['name'];
	// 	echo $_POST['designation'];
	// 	echo $_POST['email'];
		// echo "<pre>";
		// print_r($_FILES['img']);
		// echo "</pre>";

		if($_FILES['img']['size'] > 0){
			require_once(ABSPATH . 'wp-admin/includes/file.php');
			require_once(ABSPATH . 'wp-admin/includes/image.php');
			require_once(ABSPATH . 'wp-admin/includes/media.php');

			$attachment_id = media_handle_upload('img', 0);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'team_members';
		$wpdb->insert(
			$table_name,
			array(
				'name' => $_POST['name'],
				'role' => $_POST['designation'],
				'email' => $_POST['email'],
				'image' => isset($attachment_id) ? $attachment_id : null,
			)
		);

		$insert_id = $wpdb->insert_id;
		if ($insert_id) {
			echo "<div class='notice notice-success is-dismissible'>
			<p>Team member added successfully!</p></div>";
		} else {
			echo "<div class='notice notice-error is-dismissible'>
			<p>Error adding team member.</p></div>";
		}
	}


	// Code to display the form for adding a new team member
	echo "<div class='form-wrap'>
<h2>Add Team Member</h2>
<form  method='post' action='' class='validate' enctype='multipart/form-data'>

	
<div class='form-field form-required term-name-wrap'>
	<label>Name</label>
	<input name='name' id='name' type='text' value='' size='40'>
</div>
<div class='form-field term-slug-wrap'>
	<label>Designation</label>
	<input name='designation' type='text' value='' size='40'>
</div>

<div class='form-field term-slug-wrap'>
	<label>Email</label>
	<input name='email' type='text' value='' size='40'>
</div>

<div class='form-field'>
	<label>Upload Image</label>
	<input name='img' type='file' value='' size='40' accept='image/*'> 
	<input name='img_old' type='hidden' value='{$item->image}' size='40'> 
</div>

		<p class='submit'>
		<input type='submit' name='submit' id='submit' class='button button-primary' value='Add Team Member'>	<span class='spinner'></span>
	</p>
	</form></div>";
}

function team_member_edit(){
	// echo $_GET['id'];
	global $wpdb;
	$table_name = $wpdb->prefix . 'team_members';

	if (isset($_POST['submit'])) {
		$id = $_POST['id'];
		$name = $_POST['name'];
		$designation = $_POST['designation'];
		$email = $_POST['email'];
		$img = $_FILES['img'];

		

		$update_res = $wpdb->update(
			$table_name,
			array(
				'name' => $name,
				'role' => $designation,
				'email' => $email,
				'image' => ($img['size'] > 0)
    			? media_handle_upload('img', 0)
    			: $_POST['img_old'],
			),
			array('id' => $id)
		);


		if ($update_res) {
				$_SESSION['flash_msg'] = 'Team member updated successfully!';
				
				wp_redirect(admin_url('admin.php?page=team-list'));
		} else {
			echo "<div class='notice notice-error is-dismissible'>
			<p>Error updating team member.</p></div>";
		}
	}


	if (isset($_POST['submit'])){
		echo $_POST['name'];
		echo $_POST['designation'];
		echo $_POST['email'];
	}

	if(isset($_GET['id'])){
		$id= $_GET['id'];
		$item = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id");
	}
	if($item){

		// echo "<pre>";
		// print_r($item);
		// echo "</pre>";
		$name = $item->name;
		$designation = $item->role;
		$email = $item->email;

	}

	if($item->image != null){
		$img = wp_get_attachment_url($item->image);
	}else{
		$img ="https://placehold.co/60x60.png";
	}



	echo "<div class='form-wrap'>
<h2>Edit Team Member</h2>
<form  method='post' action='' class='validate' enctype='multipart/form-data'>
<input type='hidden' name='id' value='{$item->id}'>

<div class='form-field form-required term-name-wrap'>
	<label>Name</label>
	<input name='name' id='name' type='text' value='{$name}' size='40'>
</div>
<div class='form-field term-slug-wrap'>
	<label>Designation</label>
	<input name='designation' type='text' value='{$designation}' size='40'>
</div>

<div class='form-field term-slug-wrap'>
	<label>Email</label>
	<input name='email' type='text' value='{$email}' size='40'>
</div>

<div class='form-field'>
	<label>Upload Image</label>
	<input name='img' type='file' value='' size='40'>
	<input type='hidden' name='img_old' value='{$item->image}' size='40'>
</div>

<div class='form-field'>
	<label>Current Image</label>
	<img src='{$img}' width='80' height='80' alt='Team Member Image'>
</div>

	<p class='submit'>
		<input type='submit' name='submit' id='submit' class='button button-primary' value='Update Team Member'>
		<span class='spinner'></span>
	</p>
	</form></div>";

}


function team_management_db()
{
	global $wpdb;
	$table_name = $wpdb->prefix . 'team_members';

	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        email VARCHAR(100) NOT NULL,
        role VARCHAR(100) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
}
register_activation_hook(__FILE__, 'team_management_db');
