<?php

/**
 * Plugin Name: Team Management
 * Plugin URI: https://team-management.com/
 * Description: A plugin for managing teams and their activities.
 * Version: 1.0.0
 * Author: Masum
 * Author URI: https://team-management.com
 * Text Domain: team-management
 */

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

// echo "Hello, World! This is the Team Management plugin.";


function team_management_menu()
{
	add_menu_page(
		'Team Management List', // Page title
		'TeamManagement', // Menu title
		'manage_options',  // Capability
		'team-list', // Menu slug
		'team_members_list', // Callback function
		'dashicons-admin-site-alt3', // Icon URL
		6 // Position
	);

	add_submenu_page(
		'team-list', // Parent slug
		'Add Team', // Page title
		'Add Team', // Menu title
		'manage_options', // Capability
		'add-team', // Menu slug
		'team_members_add' // Callback function
	);
}

add_action('admin_menu', 'team_management_menu');

function test()
{
	echo "Hello, World! This is the Team Management plugin.";
}


function team_members_list()
{
	global $wpdb;
	$table_name = $wpdb->prefix . 'team_members';
	$results = $wpdb->get_results("SELECT * FROM $table_name");

	// echo "<pre>";
	// print_r($results);
	// echo "</pre>";

	$table_body = '';
	foreach ($results as $item) {
		$table_body .= "
	<tr>
			<td class='column-name'>{$item->name}</td>
            <td class='column-name'>{$item->role}</td>
            <td class='column-name'>{$item->email}</td>
            <td class='column-name'></td>
            <td class='column-name'></td>
	</tr>
			";
	}


	// Code to display the list of team members
	echo "<h2>Team Members List</h2>
    <table class='wp-list-table widefat fixed striped table-view-list tags'>
	<thead>
		<tr>
			<th scope='col' class='manage-column column-name column-primary sorted asc'>
				<a>Name</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Designation</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Email</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Image</a>
			</th>
			<th scope='col' class='manage-column sortable desc'>
				<a>Action</a>
			</th>
		</tr>
	</thead>
	<tbody data-wp-lists='list:tag'>
		$table_body
	</tbody>	
</table>";
}

function team_members_add()
{
	if (isset($_POST['submit'])){
		echo $_POST['name'];
		echo $_POST['designation'];
		echo $_POST['email'];

		global $wpdb;
		$table_name = $wpdb->prefix . 'team_members';
		$wpdb->insert(
			$table_name,
			array(
				'name' => $_POST['name'],
				'role2' => $_POST['designation'],
				'email' => $_POST['email'],
			)
		);

		$insert_id = $wpdb->insert_id;
		if ($insert_id) {
			echo "<div class='notice notice-success is-dismissible'><p>Team member added successfully!</p></div>";
		} else {
			echo "<div class='notice notice-error is-dismissible'><p>Error adding team member.</p></div>";
		}





	}


	// Code to display the form for adding a new team member
	echo "<div class='form-wrap'>
<h2>Add Team Member</h2>
<form  method='post' action='' class='validate'>

	
<div class='form-field form-required term-name-wrap'>
	<label>Name</label>
	<input name='name' id='name' type='text' value='' size='40'>
</div>
<div class='form-field term-slug-wrap'>
	<label>Designation</label>
	<input name='designation' type='text' value='' size='40'>
</div>

<div class='form-field term-slug-wrap'>
	<label>Email</label>
	<input name='email' type='text' value='' size='40'>
</div>

<div class='form-field'>
	<label>Upload Image</label>
	<input name='image' type='file' value='' size='40'>
</div>

		<p class='submit'>
		<input type='submit' name='submit' id='submit' class='button button-primary' value='Add Team Member'>	<span class='spinner'></span>
	</p>
	</form></div>";
}


function team_management_db()
{
	global $wpdb;
	$table_name = $wpdb->prefix . 'team_members';

	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        email VARCHAR(100) NOT NULL,
        role VARCHAR(100) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
}
register_activation_hook(__FILE__, 'team_management_db');
