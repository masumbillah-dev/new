<?php
require_once "db.php";

$sql = "
select p.*, m.name as mfg
from product p, manufacturer m
where p.manufacturer_id = m.id
";

// Show all Product

$result = $db->query($sql);
$products = $result->fetch_all(MYSQLI_ASSOC);

// Show View Product

$result_view = $db->query("SELECT * FROM product_view");
$rows_view = $result_view->fetch_all(MYSQLI_ASSOC);

// echo "<pre>";
// print_r($rows_view);
// echo "</pre>";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
</head>
<body>


   <h2>View Products</h2>
    <table border="1" cellspacing="0" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Manufacturer</th>
        </tr>
        <?php 
         foreach($rows_view as $item) :
         ?>
         <tr>
            <td><?= $item["id"] ?></td>
            <td><?= $item["name"] ?></td>
            <td><?= $item["price"] ?></td>
            <td><?= $item["mfg"] ?></td>
         </tr>

         <?php endforeach ?>
    </table>

   <h2>Products</h2>
    <table border="1" cellspacing="0" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Manufacturer</th>
        </tr>
        <?php 
         foreach($products as $item) :
         ?>
         <tr>
            <td><?= $item["id"] ?></td>
            <td><?= $item["name"] ?></td>
            <td><?= $item["price"] ?></td>
            <td><?= $item["mfg"] ?></td>
         </tr>

         <?php endforeach ?>
    </table>
</body>
</html>